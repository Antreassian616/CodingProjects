public class Main  {

    public static void main(String args[]) {

        int t;

        System.out.println(t);

    }

}